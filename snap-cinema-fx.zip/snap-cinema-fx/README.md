# Snap & Cinema FX — Chrome extension

Snap your fingers on camera and you turn to dust (Endgame style) while your room stays visible. Snap again and the dust flies back together. Raise both hands and the frame turns into the "ABSOLUTE CINEMA" meme with you in it.

Works in Google Meet and any other site that uses your webcam in Chrome (Zoom web, Teams web, Discord web, webcam test sites). Everyone on the call sees the effect, not only you.

## Install (2 minutes)

1. Unzip `snap-cinema-fx.zip` somewhere permanent (e.g. Documents\snap-cinema-fx). Don't delete the folder afterwards.
2. Open `chrome://extensions` in Chrome.
3. Turn on **Developer mode** (top-right).
4. Click **Load unpacked** and pick the unzipped `snap-cinema-fx` folder (the one containing `manifest.json`).
5. Pin the extension from the puzzle-piece icon so the settings popup is one click away.
6. Reload any Meet tab that was already open.

## Use it

Open Meet (the pre-join screen with your self-view is the perfect place to test).

**Vanish:** make a normal finger snap with your hand clearly in view — thumb and middle finger pressed together, then snap the middle finger down into your palm. You dissolve into drifting ash over about 4 seconds. Snap again to reassemble.

**Absolute Cinema:** raise both hands up beside your head, palms open, and hold for a moment. The picture goes black-and-white with letterbox bars, film grain and the title. Lower your hands and it fades out after about a second.

**Cash rain:** snap twice quickly (within about a second). Banknotes flutter down from the top of the frame for a few seconds. Because the extension waits a moment to see whether a second snap is coming, a single snap now takes just under a second to start the vanish. Turn cash rain off in the popup if you want instant vanishing.

**Absolute Cinema face-swap:** raise both hands. The whole frame becomes the Absolute Cinema meme — same pose, suit and caption — with your live face placed onto it, following your head. The picture is built in; "Change…" in the popup swaps it.

**Facepalm:** put your hand over your eyes/forehead and hold it for a moment. The Office facepalm meme fades in at 50% over you, so both you and the meme are visible. Also built in and changeable.

**Background blur:** don't use Meet's own blur with this extension — Meet blurs *after* the effects, so it smears the cash and memes. Turn Meet's blur off and switch on "Blur my background" in the extension popup instead.

**Keyboard backups** (click the call tab first): `Alt+Shift+S` snaps, `Alt+Shift+C` toggles cinema, `Alt+Shift+M` cash rain, `Alt+Shift+F` facepalm.

## Tips for the best effect

- **Let it learn your background.** The extension remembers what's behind you so the room is still there when you vanish. Lean out of frame for a second or two after your camera turns on — otherwise the spot right behind you is filled with a blurred guess.
- **Good light + hand visible.** Snap detection uses hand tracking; dark rooms or a hand half out of frame make it miss. The snap sound from your mic also helps confirm it.
- **Sensitivity:** if snaps get missed, set Snap sensitivity to *High* in the popup. If it triggers by accident, set *Low*.
- **Debug mode** in the popup draws the tracking dots and numbers on the video so you can see what it detects (others see it too, so turn it off afterwards).

## Good to know

- **Backwards text fixed:** Meet mirrors your own preview. The extension now un-mirrors your self-view so it matches what others see and text reads correctly. Turn off "Fix backwards self-view" in the popup if you prefer the mirror.
- **Turning effects on/off:** the toggle applies to the camera the next time a call starts it — turn your camera off/on in the call or reload the tab.
- **Privacy:** everything runs locally on your computer (MediaPipe models are bundled in the extension). No video or audio leaves your machine except through the call itself. The mic is only analysed locally for the snap sound.
- **Performance:** it uses your GPU when available. On older laptops, close other heavy tabs if the video gets choppy.

## How it works (for the curious)

- `inject.js` wraps `getUserMedia` on every page so the site receives a processed camera track instead of the raw one.
- `engine.html/engine.js` runs in a hidden extension frame: MediaPipe Hand Landmarker (snap + hands-up), Pose Landmarker with body segmentation (cutout + background plate), the dust particle system and the cinema grade.
- `bridge.js` connects the two; `popup.html` holds settings.
